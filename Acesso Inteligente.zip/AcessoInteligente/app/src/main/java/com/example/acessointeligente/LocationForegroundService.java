package com.example.acessointeligente;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

public class LocationForegroundService extends Service {
    private static final String CHANNEL_ID = "location_service_channel";
    private List<GeofenceData> geofenceList;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private LocationRequest locationRequest;
    private String userName;
    private PowerManager.WakeLock wakeLock;
    private final Map<String, Timer> geofenceTimers = new HashMap<>();
    private boolean isHighAccuracyMode = false; // Mantém o estado do modo atual
    private final Handler geofenceHandler = new Handler(); // Handler para gerenciar timers

    private FirebaseFirestore firestore; // Referência ao Firestore
    private SharedPreferences sharedPreferences; // Para armazenar as geofences localmente

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        firestore = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        sharedPreferences = getSharedPreferences("GeofencesPrefs", MODE_PRIVATE);

        geofenceList = new ArrayList<>();

        // Carregar geofences da coleção Firestore ou do armazenamento local
        loadGeofencesFromLocal(); // Primeiramente, tenta carregar offline
        fetchGeofencesFromFirestore(); // Atualiza a lista com dados do Firestore se houver conexão

        locationRequest = createLocationRequest(true); // Inicia com alta precisão
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    Log.d("LocationUpdate", "Location: " + location.getLatitude() + ", " + location.getLongitude());

                    // Ajusta o intervalo de atualização com base na proximidade das geofences
                    adjustLocationRequestBasedOnProximity(location);

                    // Verifica as geofences
                    checkGeofence(location);
                }
            }
        };
    }
    private void checkGeofence(Location location) {
        for (GeofenceData geofence : geofenceList) {
            float[] results = new float[1];
            Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                    geofence.getLatitude(), geofence.getLongitude(), results);
            float distance = results[0];

            boolean currentlyInsideGeofence = distance < geofence.getRadius();
            boolean wasInsideGeofence = getGeofenceState(geofence); // Recupera o estado anterior da geofence

            // Verifica se houve uma mudança no estado da geofence (dentro ou fora)
            if (currentlyInsideGeofence != wasInsideGeofence) {
                if (currentlyInsideGeofence) {
                    // Entrou na geofence
                    Log.d("GeofenceCheck", "Entrou na geofence: " + geofence.getName());
                    geofenceHandler.removeCallbacksAndMessages(geofence); // Cancela qualquer saída programada

                    // Confirma a entrada após 5 minutos (evita flutuações rápidas de GPS)
                    geofenceHandler.postDelayed(() -> {
                        if (isInsideGeofence(location, geofence)) {
                            generateGeofenceEvent(location, geofence, "Entrada Confirmada");
                            saveGeofenceState(geofence, true); // Salva o estado como 'dentro'
                        }
                    }, 5 * 60 * 1000); // 5 minutos para confirmar entrada
                } else {
                    // Saiu da geofence
                    Log.d("GeofenceCheck", "Saiu da geofence: " + geofence.getName());
                    geofenceHandler.removeCallbacksAndMessages(geofence); // Cancela qualquer entrada programada

                    // Confirma a saída após 5 minutos (evita flutuações rápidas de GPS)
                    geofenceHandler.postDelayed(() -> {
                        if (!isInsideGeofence(location, geofence)) {
                            generateGeofenceEvent(location, geofence, "Saída Confirmada");
                            saveGeofenceState(geofence, false); // Salva o estado como 'fora'
                        }
                    }, 5 * 60 * 1000); // 5 minutos para confirmar saída
                }
            }

            // Atualiza o estado da geofence no SharedPreferences
            saveGeofenceState(geofence, currentlyInsideGeofence);
            sendGeofenceUpdateBroadcast(currentlyInsideGeofence ? "Dentro da geofence: " + geofence.getName() : "Fora da geofence: " + geofence.getName());
        }
    }


    // Recupera o estado da geofence do SharedPreferences
    private boolean getGeofenceState(GeofenceData geofence) {
        // Recupera o estado armazenado, padrão é 'false' (fora da geofence)
        return sharedPreferences.getBoolean(geofence.getName(), false);
    }

    // Salva o estado da geofence no SharedPreferences
    private void saveGeofenceState(GeofenceData geofence, boolean currentlyInsideGeofence) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(geofence.getName(), currentlyInsideGeofence); // Armazena o estado da geofence
        editor.apply(); // Aplica a mudança
    }


    // Método para enviar o Broadcast com a atualização do status da geofence
    private void sendGeofenceUpdateBroadcast(String status) {
        Intent intent = new Intent("GEOFENCE_UPDATE");
        intent.putExtra("status", status);
        sendBroadcast(intent); // Envia o broadcast com a mensagem do status
    }

    // Método auxiliar para verificar se o usuário ainda está dentro da geofence
    private boolean isInsideGeofence(Location location, GeofenceData geofence) {
        float[] results = new float[1];
        Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                geofence.getLatitude(), geofence.getLongitude(), results);
        float distance = results[0];

        return distance < geofence.getRadius();
    }

    private void generateGeofenceEvent(Location location, GeofenceData geofence, String eventType) {
        // Cria uma instância de GeofenceEvent
        GeofenceEvent geofenceEvent = new GeofenceEvent(eventType, location, userName);

        // Converte o evento em um Map para enviar ao Firestore
        Map<String, Object> record = new HashMap<>();
        record.put("timestamp", geofenceEvent.getTimestamp());
        record.put("latitude", geofenceEvent.getLatitude());
        record.put("longitude", geofenceEvent.getLongitude());
        record.put("event_type", geofenceEvent.getEventType());
        record.put("geofence_name", geofence.getName());
        record.put("user_name", geofenceEvent.getUserName());

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("geofence_records").add(record)
                .addOnSuccessListener(documentReference -> {
                    Log.d("GeofenceEvent", "Evento registrado: " + eventType + " na geofence " + geofence.getName());
                })
                .addOnFailureListener(e -> {
                    Log.e("Firestore", "Erro ao registrar evento", e);
                });
    }


    // Método para carregar as geofences do Firestore
    private void fetchGeofencesFromFirestore() {
        firestore.collection("cercas")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null && !querySnapshot.isEmpty()) {
                            geofenceList.clear(); // Limpa a lista antes de adicionar os dados do Firestore
                            for (QueryDocumentSnapshot document : querySnapshot) {
                                Map<String, Object> data = document.getData();
                                // Converte latitude e longitude de string para double
                                double latitude = Double.parseDouble((String) data.get("latitude"));
                                double longitude = Double.parseDouble((String) data.get("longitude"));
                                // Converte raio de string para float
                                float radius = Float.parseFloat(String.valueOf(data.get("raio")));
                                // Nome da geofence
                                String name = (String) data.get("nome");

                                // Adiciona a geofence à lista
                                geofenceList.add(new GeofenceData(latitude, longitude, radius, name));
                            }
                            saveGeofencesToLocal(); // Salva localmente para uso offline
                        }
                    } else {
                        Log.e("Firestore", "Erro ao carregar geofences", task.getException());
                    }
                });
    }

    // Salva as geofences no SharedPreferences para uso offline
    private void saveGeofencesToLocal() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        JSONArray geofencesJsonArray = new JSONArray();

        try {
            for (GeofenceData geofence : geofenceList) {
                JSONObject geofenceJson = new JSONObject();
                geofenceJson.put("latitude", geofence.getLatitude());
                geofenceJson.put("longitude", geofence.getLongitude());
                geofenceJson.put("radius", geofence.getRadius());
                geofenceJson.put("name", geofence.getName());
                geofencesJsonArray.put(geofenceJson);
            }
            editor.putString("geofences", geofencesJsonArray.toString());
            editor.apply(); // Salva no SharedPreferences
        } catch (JSONException e) {
            Log.e("GeofencesSave", "Erro ao salvar geofences localmente", e);
        }
    }

    // Carrega as geofences do SharedPreferences para uso offline
    private void loadGeofencesFromLocal() {
        String geofencesString = sharedPreferences.getString("geofences", null);
        if (geofencesString != null) {
            try {
                JSONArray geofencesJsonArray = new JSONArray(geofencesString);
                for (int i = 0; i < geofencesJsonArray.length(); i++) {
                    JSONObject geofenceJson = geofencesJsonArray.getJSONObject(i);
                    double latitude = geofenceJson.getDouble("latitude");
                    double longitude = geofenceJson.getDouble("longitude");
                    float radius = (float) geofenceJson.getDouble("radius");
                    String name = geofenceJson.getString("name");
                    geofenceList.add(new GeofenceData(latitude, longitude, radius, name));
                }
            } catch (JSONException e) {
                Log.e("GeofencesLoad", "Erro ao carregar geofences localmente", e);
            }
        }
    }

    // Ajusta a precisão do LocationRequest dinamicamente
    private void adjustLocationRequestBasedOnProximity(Location location) {
        boolean isCloseToAnyGeofence = false;

        for (GeofenceData geofence : geofenceList) {
            float[] results = new float[1];
            Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                    geofence.getLatitude(), geofence.getLongitude(), results);
            float distance = results[0];

            if (distance < geofence.getRadius() + 50) { // Margem de proximidade de 50 metros
                isCloseToAnyGeofence = true;
                break;
            }
        }

        // Verifica se é necessário ajustar o LocationRequest
        if (isCloseToAnyGeofence && !isHighAccuracyMode) {
            isHighAccuracyMode = true;
            LocationRequest locationRequest = createLocationRequest(true);
            restartLocationUpdates(locationRequest);
        } else if (!isCloseToAnyGeofence && isHighAccuracyMode) {
            isHighAccuracyMode = false;
            LocationRequest locationRequest = createLocationRequest(false);
            restartLocationUpdates(locationRequest);
        }
    }

    // Método para reiniciar as atualizações de localização
    private void restartLocationUpdates(LocationRequest locationRequest) {
        fusedLocationClient.removeLocationUpdates(locationCallback);
        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        } catch (SecurityException e) {
            Log.e("LocationService", "Permissão de localização não concedida.", e);
        }
    }

    // Método para criar o LocationRequest com base na precisão desejada
    private LocationRequest createLocationRequest(boolean highAccuracy) {
        LocationRequest.Builder builder;

        if (highAccuracy) {
            builder = new LocationRequest.Builder(LocationRequest.PRIORITY_HIGH_ACCURACY)
                    .setMinUpdateIntervalMillis(5000) // Atualização mínima de 5 segundos
                    .setMaxUpdateDelayMillis(30000); // Atualização máxima de 30 segundos
        } else {
            builder = new LocationRequest.Builder(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY)
                    .setMinUpdateIntervalMillis(2 * 60 * 1000) // Atualização mínima de 2 minutos
                    .setMaxUpdateDelayMillis(5 * 60 * 1000); // Atualização máxima de 5 minutos
        }

        return builder.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            userName = intent.getStringExtra("USER_NAME"); // Armazena o nome do usuário
        }
        startForeground(1, createNotification()); // Exibe a notificação do serviço em primeiro plano
        startLocationUpdates(); // Inicia as atualizações de localização
        return START_STICKY; // Permite que o serviço continue rodando após ser encerrado
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Serviço de Localização")
                .setContentText("Monitorando sua localização")
                .setSmallIcon(R.drawable.ic_launcher_foreground) // Substitua pelo seu ícone
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }


    private void createNotificationChannel() {
        NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_ID,
                "Location Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(serviceChannel);
    }

    private void startLocationUpdates() {
        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        } catch (SecurityException e) {
            Log.e("LocationForegroundService", "Permissão de localização não concedida.", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseWakeLock(); // Libera o WakeLock
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    private void releaseWakeLock() {
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // Não é um serviço vinculado
    }
}
