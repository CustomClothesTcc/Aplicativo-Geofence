package com.example.acessointeligente;

import android.location.Location;

import com.google.firebase.Timestamp; // Importa o Timestamp do Firebase

public class GeofenceEvent {
    private String eventType;
    private double latitude;
    private double longitude;
    private Timestamp timestamp; // Usando Timestamp do Firebase
    private String userName;

    // Construtor
    public GeofenceEvent(String eventType, Location location, String userName) {
        this.eventType = eventType;
        this.latitude = location.getLatitude();
        this.longitude = location.getLongitude();
        this.timestamp = new Timestamp(new java.util.Date()); // Usa a data e hora atual
        this.userName = userName;
    }

    // Método para obter o timestamp
    public Timestamp getTimestamp() {
        return timestamp;
    }

    public String getEventType() {
        return eventType;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getUserName() {
        return userName;
    }
}