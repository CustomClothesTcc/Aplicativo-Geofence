package com.example.acessointeligente;

import android.content.Context;
import android.util.Log;

import com.example.acessointeligente.GeofenceData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class GeofenceFileManager {

    private Context context;

    // Construtor da classe que recebe o contexto da aplicação
    public GeofenceFileManager(Context context) {
        this.context = context;
    }

    // Método para salvar as cercas no arquivo JSON
    public void saveGeofencesToJsonFile(List<GeofenceData> geofenceList) {
        JSONArray geofencesJsonArray = new JSONArray();
        try {
            for (GeofenceData geofence : geofenceList) {
                JSONObject geofenceJson = new JSONObject();
                geofenceJson.put("latitude", geofence.getLatitude());
                geofenceJson.put("longitude", geofence.getLongitude());
                geofenceJson.put("radius", geofence.getRadius());
                geofenceJson.put("name", geofence.getName());
                geofencesJsonArray.put(geofenceJson);
            }
            // Escreve o JSON em um arquivo no armazenamento interno
            String jsonString = geofencesJsonArray.toString();
            writeToFile(jsonString, "geofences.json");
        } catch (JSONException e) {
            Log.e("GeofencesSave", "Erro ao salvar geofences no arquivo JSON", e);
        }
    }

    // Método para escrever dados no arquivo
    private void writeToFile(String data, String filename) {
        try {
            FileOutputStream fos = context.openFileOutput(filename, Context.MODE_PRIVATE);
            fos.write(data.getBytes());
            fos.close();
        } catch (IOException e) {
            Log.e("WriteFile", "Erro ao escrever arquivo: " + e.getMessage());
        }
    }

    // Método para ler o arquivo JSON
    public String readFromFile(String filename) {
        String jsonString = "";
        try {
            FileInputStream fis = context.openFileInput(filename);
            int character;
            StringBuilder stringBuilder = new StringBuilder();
            while ((character = fis.read()) != -1) {
                stringBuilder.append((char) character);
            }
            jsonString = stringBuilder.toString();
            fis.close();
        } catch (IOException e) {
            Log.e("ReadFile", "Erro ao ler arquivo: " + e.getMessage());
        }
        return jsonString;
    }
}
