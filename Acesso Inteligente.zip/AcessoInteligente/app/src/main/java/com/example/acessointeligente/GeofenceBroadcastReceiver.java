package com.example.acessointeligente;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Verifica se o Intent tem a ação esperada
        if (intent.getAction().equals("GEOFENCE_UPDATE")) {
            // Extrai o status enviado pelo broadcast
            String status = intent.getStringExtra("status");

            // Log para depuração
            Log.d("GeofenceBroadcast", "Geofence status: " + status);

            // Exibe um Toast com o status
            Toast.makeText(context, "Geofence Update: " + status, Toast.LENGTH_LONG).show();

            // Você pode adicionar mais lógica aqui, como atualizar a UI, notificar o usuário, etc.
        }
    }
}
