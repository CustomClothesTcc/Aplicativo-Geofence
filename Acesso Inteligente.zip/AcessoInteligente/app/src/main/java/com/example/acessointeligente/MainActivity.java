package com.example.acessointeligente;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private TextView statusTextView;
    private FirebaseFirestore db;
    private GeofenceBroadcastReceiver geofenceReceiver;  // Variável para o receiver da geofence

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa o Firebase
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();

        // Inicializa o TextView para exibir o status
        statusTextView = findViewById(R.id.statusTextView);

        // Verifica se o nome do usuário já foi salvo nas SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        String userName = sharedPreferences.getString("USER_NAME", null);

        // Se o nome não existir, redireciona para a InputActivity
        if (userName == null) {
            Intent intent = new Intent(MainActivity.this, InputActivity.class);
            startActivity(intent);
            finish(); // Fecha a MainActivity
            return; // Evita continuar a execução da MainActivity
        }

        // Exibe a mensagem de boas-vindas com o nome do usuário
        statusTextView.setText("Bem-vindo, " + userName);

        // Verifica a permissão de localização
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            startLocationService(userName); // Passa o nome do usuário para o serviço de localização
        }

        // Inicializa o BroadcastReceiver para geofences
        geofenceReceiver = new GeofenceBroadcastReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Registra o BroadcastReceiver para escutar pelo Intent "GEOFENCE_UPDATE"
        IntentFilter filter = new IntentFilter("GEOFENCE_UPDATE");
        registerReceiver(geofenceReceiver, filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Desregistra o BroadcastReceiver para evitar leaks de memória
        unregisterReceiver(geofenceReceiver);
    }

    // Método modificado para aceitar o nome do usuário
    private void startLocationService(String userName) {
        Intent serviceIntent = new Intent(this, LocationForegroundService.class);
        serviceIntent.putExtra("USER_NAME", userName); // Adiciona o nome como extra
        startService(serviceIntent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Obtém o nome do usuário novamente para iniciar o serviço de localização
                SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
                String userName = sharedPreferences.getString("USER_NAME", null);
                startLocationService(userName); // Passa o nome do usuário
            } else {
                statusTextView.setText("Permissão de localização negada");
            }
        }
    }
}
